var products = [
    {
        id: 1,
        name: "The bastard small",
        category: 219,
        omshrijving: 0,
        image: "img_1.jpg"
    },
    {
        id: 1,
        name: "The bastard small",
        category: 219,
        omshrijving: 0,
        image: "img_1.jpg"
    },
    {
        id: 1,
        name: "The bastard small",
        category: 219,
        omshrijving: 0,
        image: "img_1.jpg"
    },
    {
        id: 1,
        name: "The bastard small",
        category: 219,
        omshrijving: 0,
        image: "img_1.jpg"
    },
    {
        id: 1,
        name: "The bastard small",
        category: 219,
        omshrijving: 0,
        image: "img_1.jpg"
    },
    {
        id: 1,
        name: "The bastard small",
        category: 219,
        omshrijving: 0,
        image: "img_1.jpg"
    }
]
function toontable()
function bewaren()

function verwijderen(btn) {
    var row = btn.parentNode.parentNode;
    row.parentNode.removeChild(row);
  }